
/* Midi Support
----------------------------------------------------------------------------*/

let midi = null;
const logLevel = 1; // 0: no logs, 1: log midi access, 2: log midi messages

const listMidiInputsAndOutputs = (midiAccess) => {

  const result = [...midiAccess.inputs].map(([key, value]) => {
    return `
      <tr class="midi-device">
        <td>${value.type}</td>
        <td>${value.name}</td>
        <td>${value.id}</td>
      </tr>
    `;
    
  });

  const deviceTable =  `
    <table class="midi-devices">
      <thead>
        <tr>
          <th>Type</th>
          <th>Name</th>
          <th>ID</th>
        </tr>
      </thead>

      <tbody>
      ${result.join('')}
      </tbody>
    </table>
  `;

  const target = document.querySelector("#midi-devices");

  if(!target){
    return;
  }

  target.innerHTML = deviceTable;

  return; 

}

const handleInputAction = (trigger, value, type) => {

  if(typeof midiMode !== 'undefined' && midiMode === 'detection'){
    const target = document.querySelector("#show-input");
    if(!target) return;
    target.innerHTML = `Trigger: ${trigger}, Value: ${value}, Type: ${type}`;
    return event.data;
  }

  if (typeof midiMap === 'undefined') return;

  midiMap[trigger] = midiMap[trigger] || false;
  if(midiMap[trigger]){
    const param = midiMap[trigger];
    const max = drawingParams[param + "Max"] 
      ? drawingParams[param + "Max"] : 100;
    const min = drawingParams[param + "Min"]
      ? drawingParams[param + "Min"] : 0;

    sketchGUI.update(midiMap[trigger], map(value, 0, 127, min, max));
  }
  
};

const handleMIDIMessage = (event) => {
  const [status, control, value] = event.data;

  // Check if it's a Control Change message (CC starts with 0xB0 for channel 1)
  if (status >= 176 && status <= 191) {

    if(logLevel >= 2){
      console.log(`ControlerID: ${control}, Value: ${value}`);
    }

    handleInputAction(control, value, 'controller');


  }else{
    if(logLevel >= 2){
      console.log(`NoteID: ${control}, Value: ${value}`);
    }

    handleInputAction(control, value, 'note');
  }

}

const startLoggingMIDIInput = (midiAccess) => {
  midiAccess.inputs.forEach((entry) => {
    entry.onmidimessage = handleMIDIMessage;
  });
}

const onMIDISuccess = (midiAccess) => {

  if (logLevel >= 1) {
    console.log("MIDI ready!");
  }

  midi = midiAccess;
  listMidiInputsAndOutputs(midi);
  startLoggingMIDIInput(midi);
}

const onMIDIFailure = (msg) => {
  console.error(`Failed to get MIDI access - ${msg}`);
}