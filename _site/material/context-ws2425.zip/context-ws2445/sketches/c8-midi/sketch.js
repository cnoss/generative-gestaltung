/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

const saveParams = {
  sketchName: "gg-sketch"
}

// Params for canvas
const canvasParams = {
  holder: document.getElementById('canvas'),
  state: false,
  mouseX: false,
  mouseY: false,
  mouseLock: false,
  background: 0,
  gui: true,
  mode: 'canvas', // canvas or svg … SVG mode is experimental 
};
getCanvasHolderSize();

// Params for the drawing
const drawingParams = {
  groesse: 20,
  yPos: 100,
};

// Params for logging
const loggingParams = {
  targetDrawingParams: document.getElementById('drawingParams'),
  targetCanvasParams: document.getElementById('canvasParams'),
  state: false
};


const midiMap = {
  28: 'groesse',
  72: 'yPos',
};


let sketchGUI = false;




/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */


/* Midi Support
----------------------------------------------------------------------------*/

let midi = null;
const logLevel = 1; // 0: no logs, 1: log midi access, 2: log midi messages

const listMidiInputsAndOutputs = (midiAccess) => {

  const result = [...midiAccess.inputs].map(([key, value]) => {
    return `
      <tr class="midi-device">
        <td>${value.type}</td>
        <td>${value.name}</td>
        <td>${value.id}</td>
      </tr>
    `;
    
  });

  const deviceTable =  `
    <table class="midi-devices">
      <thead>
        <tr>
          <th>Type</th>
          <th>Name</th>
          <th>ID</th>
        </tr>
      </thead>

      <tbody>
      ${result.join('')}
      </tbody>
    </table>
  `;

  const target = document.querySelector("#midi-devices");

  if(!target){
    return;
  }

  target.innerHTML = deviceTable;

  return; 

}

const handleInputAction = (trigger, value, type) => {

  if(trigger > 48 && trigger < 72){

    const xPos = map(value, 48, 72, 0, width);
    zeichnePunkt(xPos);
  }

  if(typeof midiMode !== 'undefined' && midiMode === 'detection'){
    const target = document.querySelector("#show-input");
    if(!target) return;
    target.innerHTML = `Trigger: ${trigger}, Value: ${value}, Type: ${type}`;
    return event.data;
  }

  if (typeof midiMap === 'undefined') return;

  midiMap[trigger] = midiMap[trigger] || false;
  if(midiMap[trigger]){
    const param = midiMap[trigger];
    const max = drawingParams[param + "Max"] 
      ? drawingParams[param + "Max"] : 100;
    const min = drawingParams[param + "Min"]
      ? drawingParams[param + "Min"] : 0;

    sketchGUI.update(midiMap[trigger], map(value, 0, 127, min, max));
  }
  
};

const handleMIDIMessage = (event) => {
  const [status, control, value] = event.data;

  // Check if it's a Control Change message (CC starts with 0xB0 for channel 1)
  if (status >= 176 && status <= 191) {

    if(logLevel >= 2){
      console.log(`ControlerID: ${control}, Value: ${value}`);
    }

    handleInputAction(control, value, 'controller');


  }else{
    if(logLevel >= 2){
      console.log(`NoteID: ${control}, Value: ${value}`);
    }

    handleInputAction(control, value, 'note');
  }

}

const startLoggingMIDIInput = (midiAccess) => {
  midiAccess.inputs.forEach((entry) => {
    entry.onmidimessage = handleMIDIMessage;
  });
}

const onMIDISuccess = (midiAccess) => {

  if (logLevel >= 1) {
    console.log("MIDI ready!");
  }

  midi = midiAccess;
  listMidiInputsAndOutputs(midi);
  startLoggingMIDIInput(midi);
}

const onMIDIFailure = (msg) => {
  console.error(`Failed to get MIDI access - ${msg}`);
}

function zeichnePunkt(xPos){

  console.log("xPos", xPos);
  const groesse = drawingParams.groesse;
  const yPos = drawingParams.yPos;

  ellipse(xPos,yPos,groesse);
}



/* ###########################################################################
P5 Functions
############################################################################ */

function setup() {

  let canvas;
  if (canvasParams.mode === 'SVG') {
    canvas = createCanvas(canvasParams.w, canvasParams.h, SVG);
  } else { 
    canvas = createCanvas(canvasParams.w, canvasParams.h);
    canvas.parent("canvas");
  }

  // Display & Render Options
  frameRate(25);
  angleMode(DEGREES);
  smooth();

  // GUI Management
  if (canvasParams.gui) { 
    sketchGUI = createGui('Params');
    sketchGUI.addObject(drawingParams);
    //noLoop();
  }

  // Anything else
  fill(200);
  // stroke(0);
  noStroke();
  // ellipseMode(CORNERS);

  background(255);
  
  navigator.requestMIDIAccess().then(onMIDISuccess, onMIDIFailure);

}



function draw() {

  /* ----------------------------------------------------------------------- */
  // Log globals
  if (!canvasParams.mouseLock) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }

  /* ----------------------------------------------------------------------- */
  // Provide your Code below
  // background(255);
  fill(0);

  zeichnePunkt(width/2);
  

}



function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    const suffix = (canvasParams.mode === "canvas") ? '.jpg' : '.svg';
    const fragments = location.href.split(/\//).reverse();
    const suggestion = fragments[1] ? fragments[1] : 'gg-sketch';
    const fn = prompt(`Filename for ${suffix}`, suggestion);
    save(fn + suffix);
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

  if (keyCode === 76) { // L-Key
    if (!canvasParams.mouseLock) {
      canvasParams.mouseLock = true;
    } else { 
      canvasParams.mouseLock = false;
    }
    document.getElementById("canvas").classList.toggle("mouseLockActive");
  }


}



function mousePressed() {}



function mouseReleased() {}



function mouseDragged() {}



function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}





/* ###########################################################################
Service Functions
############################################################################ */



function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}



function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}



function windowResized() {
  resizeMyCanvas();
}



function logInfo(content) {

  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }

}

