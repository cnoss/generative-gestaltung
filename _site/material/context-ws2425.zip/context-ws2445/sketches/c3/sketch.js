/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

const saveParams = {
  sketchName: "gg-sketch"
}

// Params for canvas
const canvasParams = {
  holder: document.getElementById('canvas'),
  state: false,
  mouseX: false,
  mouseY: false,
  mouseLock: false,
  background: 0,
  gui: true,
  mode: 'canvas', // canvas or svg … SVG mode is experimental 
};
getCanvasHolderSize();

// Params for the drawing
const drawingParams = {
  rotAngle: 0,
  maxBrightness: 10,
  farbe: 0,
  spread: 10
};

// Params for logging
const loggingParams = {
  targetDrawingParams: document.getElementById('drawingParams'),
  targetCanvasParams: document.getElementById('canvasParams'),
  state: false
};


let buffer = [];
let size = 0;
let pSize = 0;
let virtualCanvas;
let mic;
let copies = 1;


/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */

function doDraw() {
  background(0);
  drawingParams.rotAngle = 360 / copies;

  translate(width / 2, height / 2);

  for (let i = 0; i < copies; i++) {
    push()
    rotate(i * drawingParams.rotAngle);

    image(virtualCanvas, (width * -0.5) + drawingParams.spread, (height * -0.5) + drawingParams.spread);
    pop();

  }
}



/* ###########################################################################
P5 Functions
############################################################################ */

function setup() {

  let canvas;
  if (canvasParams.mode === 'SVG') {
    canvas = createCanvas(canvasParams.w, canvasParams.h, SVG);
  } else {
    canvas = createCanvas(canvasParams.w, canvasParams.h);
    canvas.parent("canvas");
  }

  // Display & Render Options
  frameRate(25);
  angleMode(DEGREES);
  smooth();

  // GUI Management
  if (canvasParams.gui) {
    const sketchGUI = createGui('Params');
    sketchGUI.addObject(drawingParams);
    //noLoop();
  }

  // Anything else
  fill(200);
  stroke(0);

  // Video Input
  pixelDensity(1);
  video = createCapture(VIDEO);
  video.size(300, 200);

  // Audio Input
  mic = new p5.AudioIn();
  mic.start();


  virtualCanvas = createGraphics(width, height);
  virtualCanvas.colorMode(HSB, 360, 100, 100, 100);
  virtualCanvas.fill(255, 2);
  virtualCanvas.stroke(0, 10);
  virtualCanvas.strokeWeight(1);
  virtualCanvas.smooth();
}



function draw() {

  /* ----------------------------------------------------------------------- */
  // Log globals
  if (!canvasParams.mouseLock) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }

  /* ----------------------------------------------------------------------- */
  // Provide your Code below
  background(200,0,0,5);
  fill(0);

  video.loadPixels();
  drawingParams.maxBrightness = (video.pixels[0] > drawingParams.maxBrightness) ? video.pixels[0] : drawingParams.maxBrightness;
  drawingParams.farbe = map(video.pixels[0], 0, drawingParams.maxBrightness, 0, 360); 
  
  copies = map(mic.getLevel(), 0, 1, 0, 120);
  
  
  if (mouseIsPressed) {
    let distance = dist(mouseX, mouseY, pmouseX, pmouseY);
    let sizeDiff = (size - pSize) / distance;
    let posX = pmouseX;
    let posY = pmouseY;
    let xMove = (mouseX - pmouseX) / distance;
    let yMove = (mouseY - pmouseY) / distance;
    size = (map(distance, 0, 50, 2, 20));
    
    let trans = map(dist(pmouseX, pmouseY, width / 2, height / 2), 0, height / 2, 20, 1);
    
    virtualCanvas.fill(drawingParams.farbe, 90, 100, trans);
    for (let i = 0; i < distance; i++) {
      virtualCanvas.ellipse(posX, posY, size);
      size += sizeDiff;
      posX += xMove;
      posY += yMove;
    }
    pSize = size;

    
  }

  doDraw();
}



function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    const suffix = (canvasParams.mode === "canvas") ? '.jpg' : '.svg';
    const fragments = location.href.split(/\//).reverse();
    const suggestion = fragments[1] ? fragments[1] : 'gg-sketch';
    const fn = prompt(`Filename for ${suffix}`, suggestion);
    if (fn !== null) save(fn + suffix);
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

  if (keyCode === 76) { // L-Key
    if (!canvasParams.mouseLock) {
      canvasParams.mouseLock = true;
    } else {
      canvasParams.mouseLock = false;
    }
    document.getElementById("canvas").classList.toggle("mouseLockActive");
  }


}



function mousePressed() { }



function mouseReleased() { }



function mouseDragged() { }



function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}





/* ###########################################################################
Service Functions
############################################################################ */



function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}



function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}



function windowResized() {
  resizeMyCanvas();
}



function logInfo(content) {

  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }

}

