/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

const saveParams = {
  sketchName: "gg-sketch"
}

// Params for canvas
const canvasParams = {
  holder: document.getElementById('canvas'),
  state: false,
  mouseX: false,
  mouseY: false,
  mouseLock: false,
  background: 0,
  gui: true,
  mode: 'canvas', // canvas or svg … SVG mode is experimental 
};
getCanvasHolderSize();

// Params for the drawing
const drawingParams = {
  zeilenhoeheRangeStart: 40,
  zeilenhoeheRangeEnde: 80,
  hintergrundAlpha: 10,
  shiftX: 0,
};

// Params for logging
const loggingParams = {
  targetDrawingParams: document.getElementById('drawingParams'),
  targetCanvasParams: document.getElementById('canvasParams'),
  state: false
};

let handPose;;
let video;
let hands = [];

let doLoop = false;
let shiftX = 0;
let scaleFactor = 1;

/* ###########################################################################
Classes
############################################################################ */




/* ###########################################################################
Custom Functions
############################################################################ */

function gotHands(results) {
  // Save the output to the hands variable
  hands = results;
}

function showCross() {
  stroke(0);
  line(width/2, 0, width/2, height);
  line(0, height/2, width, height/2);
}

function zeichneReihe(abstand, zeilenhoehe, yPosReihe){
  let xPos = 0;

  const farbwinkel = random(20, 80);
  const saettigung = random(20, 60);
  const helligkeit = random(60, 100);
  stroke(farbwinkel, saettigung, helligkeit);

  while(xPos < width) {
    const shiftXRandom = random(-shiftX, shiftX);
    line(xPos, yPosReihe, xPos + shiftXRandom, yPosReihe + zeilenhoehe);
    xPos += abstand;
  }
}



/* ###########################################################################
P5 Functions
############################################################################ */


function preload() {
  handPose = ml5.handPose();
}

function setup() {

  let canvas;
  if (canvasParams.mode === 'SVG') {
    canvas = createCanvas(canvasParams.w, canvasParams.h, SVG);
  } else { 
    canvas = createCanvas(canvasParams.w, canvasParams.h);
    canvas.parent("canvas");
  }

  // Display & Render Options
  frameRate(25);
  angleMode(DEGREES);
  smooth();
  colorMode(HSB, 356, 100, 100, 100);

  // GUI Management
  if (canvasParams.gui) { 
    const sketchGUI = createGui('Params');
    sketchGUI.addObject(drawingParams);
    //noLoop();
  }

  // Anything else
  fill(200);
  stroke(0);
  strokeCap(SQUARE);

  // Create the video and hide it
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide();

  handPose.detectStart(video, gotHands);
}




function draw() {

  /* ----------------------------------------------------------------------- */
  // Log globals
  if (!canvasParams.mouseLock) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }

  /* ----------------------------------------------------------------------- */
  // Provide your Code below
  
  randomSeed(0);
  let yPosReihe = 0;

  const zeilenhoeheMin = drawingParams.zeilenhoeheRangeStart;
  const zeilenhoeheMax = drawingParams.zeilenhoeheRangeEnde;
  const hintergrundAlpha = drawingParams.hintergrundAlpha;

  background(0, hintergrundAlpha);
  stroke(255);


  while(yPosReihe < height) {

    const linienstaerke = random(0, 8);
    strokeWeight(linienstaerke);
    const zeilenhoehe = random(zeilenhoeheMin, zeilenhoeheMax);
    const abstand = random(linienstaerke + 1, linienstaerke + 30);
    zeichneReihe(abstand, zeilenhoehe, yPosReihe);
    yPosReihe += zeilenhoehe + 1;
  }

//  console.log(hands);
  for (let i = 0; i < hands.length; i++) {
    let hand = hands[i];


    if(hand.handedness === 'Left' && hand.confidence > 0.9) {
      const indexFinder = hand.index_finger_tip;
      const thumb = hand.thumb_tip;
      const wrist = hand.wrist;
      const distance = dist(indexFinder.x, indexFinder.y, thumb.x, thumb.y);
      
      square(wrist.x, height, 5);
      shiftX = map(distance, 0, 200, 0, 10);
    }

  }


}



function keyPressed() {

  if (keyCode === 81) { // Q-Key
    doLoop = !doLoop;

    if (doLoop) {
      loop();
    } else {
      noLoop();
    }
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    const suffix = (canvasParams.mode === "canvas") ? '.jpg' : '.svg';
    const fragments = location.href.split(/\//).reverse();
    const suggestion = fragments[1] ? fragments[1] : 'gg-sketch';
    const fn = prompt(`Filename for ${suffix}`, suggestion);
    save(fn + suffix);
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

  if (keyCode === 76) { // L-Key
    if (!canvasParams.mouseLock) {
      canvasParams.mouseLock = true;
    } else { 
      canvasParams.mouseLock = false;
    }
    document.getElementById("canvas").classList.toggle("mouseLockActive");
  }


}



function mousePressed() {}



function mouseReleased() {}



function mouseDragged() {}



function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}





/* ###########################################################################
Service Functions
############################################################################ */



function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}



function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}



function windowResized() {
  resizeMyCanvas();
}



function logInfo(content) {

  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }

}

