/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

Hier wird Tramontana gebraucht:
https://tramontana.xyz/tramontanajavascriptgettingstarted_2_2

############################################################################ */


let saveParams = {
  sketchName: "C1"
}

// Params for canvas
let canvasParams = {
  holder: document.getElementById("canvas"),
  state: false,
  mouseX: false,
  mouseY: false,
  background: 0
};
getCanvasHolderSize();

// Params for the drawing
let drawingParams = {
  x: 0,
  y: 1,
  w: 10,
  cw: 0
};

// Params for logging
let loggingParams = {
  targetDrawingParams: document.getElementById("drawingParams"),
  targetCanvasParams: document.getElementById("canvasParams"),
  state: false
};



/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */




/* ###########################################################################
P5 Functions
############################################################################ */


function setup() {

  let canvas = createCanvas(canvasParams.w, canvasParams.h);
  canvas.parent("canvas");

  
  colorMode(HSB, 360, 100, 100, 100);
  noStroke();
  angleMode(DEGREES);

  let sketchGUI = createGui('Params');
  sketchGUI.addObject(drawingParams);


  // only call draw when then gui is changed
  // noLoop();
}


function draw() {
  

  // Log globals
  if (loggingParams) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }
}

function keyPressed() {

  if (keyCode === 81) { // Q-Key
    virtualCanvas.clear();
    doDraw();
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    save(saveParams.sketchName + '.jpg');
  }

  if (keyCode === 49) { // 1-Key
    if (drawingParams.virtualCanvases > 2) { 
      drawingParams.virtualCanvases--;
      doDraw();
    }
  }

  if (keyCode === 50) { // 2-Key
    drawingParams.virtualCanvases++;
    doDraw();
  }

}

function mousePressed() {

}

function mouseReleased() {

}

function mouseDragged() {

}

function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}



/* ###########################################################################
Service Functions
############################################################################ */

function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}

function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}

function windowResized() {
  resizeMyCanvas();
}

function logInfo(content) {
  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }
}

