/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

let videoCapture;
const handimg = document.getElementById("handimage");
const canvasHT = document.getElementById("canvasHT");
const context = canvasHT.getContext("2d");

const modelParams = {
  flipHorizontal: true,   // flip e.g for video  
  maxNumBoxes: 20,        // maximum number of boxes to detect
  iouThreshold: 0.5,      // ioU threshold for non-max suppression
  scoreThreshold: 0.6,    // confidence threshold for predictions.
}

let imgindex = 1;
let isVideo = false;
let model = null;

let saveParams = {
  sketchName: "C1"
}

// Params for canvas
let canvasParams = {
  holder: document.getElementById("canvas"),
  state: false,
  mouseX: false,
  mouseY: false,
  background: 0
};
getCanvasHolderSize();

// Params for the drawing
let drawingParams = {
  x: 0,
  y: 1,
  w: 10,
  cw: 0
};

// Params for logging
let loggingParams = {
  targetDrawingParams: document.getElementById("drawingParams"),
  targetCanvasParams: document.getElementById("canvasParams"),
  state: false
};



/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */

function startVideo() {
  handTrack.startVideo(videoCapture).then(function (status) {
      if (status) {
          isVideo = true
          runDetection()
      } else {
      }
  });
}

function runDetection() {
  model.detect(videoCapture).then(predictions => {
    //console.log("Predictions: ", predictions);
    if (predictions[0]) {
      [drawingParams.x, drawingParams.y, drawingParams.w] = predictions[0].bbox;
    }
    if (predictions[1]) {
      [drawingParams.cw] = predictions[1].bbox;
    }
    if (isVideo) {
      requestAnimationFrame(runDetection);
    }
  });
}


/* ###########################################################################
P5 Functions
############################################################################ */


function setup() {

  let canvas = createCanvas(canvasParams.w, canvasParams.h);
  canvas.parent("canvas");

  
  colorMode(HSB, 360, 100, 100, 100);
  noStroke();
  angleMode(DEGREES);

  let sketchGUI = createGui('Params');
  sketchGUI.addObject(drawingParams);

  // Video Input
  pixelDensity(1);
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.class("previewVideo");
  video.id("video");
  videoCapture = document.getElementById("video");
  video.hide();

  // Load the model and start video
  handTrack.load(modelParams).then(lmodel => {
    model = lmodel
    startVideo();
  });

  // only call draw when then gui is changed
  // noLoop();
}


function draw() {
  
  let x = map(drawingParams.x, 0, 320, 0, width);
  let y = map(drawingParams.y, 0, 240, 0, height);
  let w = map(drawingParams.y, 0, 320, 0, 100);
  let cw = map(drawingParams.cw, 0, 320, 0, 360);

  fill(cw,100,100, 20);
  ellipse(x, y, w);

  push(); 
  translate(video.width,0); 
  scale(-1.0,1.0); 
  image(video,0,0); 
  pop();
  
  // Log globals
  if (loggingParams) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }
}

function keyPressed() {

  if (keyCode === 81) { // Q-Key
    virtualCanvas.clear();
    doDraw();
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    save(saveParams.sketchName + '.jpg');
  }

  if (keyCode === 49) { // 1-Key
    if (drawingParams.virtualCanvases > 2) { 
      drawingParams.virtualCanvases--;
      doDraw();
    }
  }

  if (keyCode === 50) { // 2-Key
    drawingParams.virtualCanvases++;
    doDraw();
  }

}

function mousePressed() {

}

function mouseReleased() {

}

function mouseDragged() {

}

function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}



/* ###########################################################################
Service Functions
############################################################################ */

function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}

function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}

function windowResized() {
  resizeMyCanvas();
}

function logInfo(content) {
  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }
}

