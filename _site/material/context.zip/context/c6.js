/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */


let saveParams = {
  sketchName: "gg-sketch"
}


// Params for canvas
let canvasParams = {
  holder: document.getElementById("canvas"),
  state: false,
  mouseX: false,
  mouseY: false,
  background: 0,
  gui: false
};
getCanvasHolderSize();

// Params for the drawing
let drawingParams = {
  deviceData: {
    r: 0,
    y: 0,
    p: 0,
    dist: 0
  },
    
  rMax: false,
  pMax: false,
  yMax: false
};

// Params for logging
let loggingParams = {
  targetDrawingParams: document.getElementById("drawingParams"),
  targetCanvasParams: document.getElementById("canvasParams"),
  state: false
};

let device = new tramontana();
let deviceData = false;
console.info = function() {}



/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */





/* ###########################################################################
P5 Functions
############################################################################ */


function setup() {

  let canvas = createCanvas(canvasParams.w, canvasParams.h);
  canvas.parent("canvas");

  //frameRate(0.5);
  angleMode(DEGREES);
  smooth();

  if (canvasParams.gui) { 
    let sketchGUI = createGui('Params');
    sketchGUI.addObject(drawingParams);
    noLoop();
  }

  device.start("10.1.85.115", function (e) {
    if (e == undefined) {
      device.makeVibrate();
      device.subscribeAttitude( 60 ,function(ip,e){
        drawingParams.deviceData.r = e.r;
        drawingParams.deviceData.y = e.y;
        drawingParams.deviceData.p = e.p;
        // e.r = roll (x)
        // e.y = yaw (y)
        // e.p = pitch (z)
        // console.log(e);
      });
      device.subscribeDistance(function(ip, e) { 
        drawingParams.deviceData.distance = e;
        // console.log(e);
      });      
    } else { 
      console.log(e);
    }
  });
}


function draw() {

  translate(width/2, height/2);
  drawingParams.rMax = (drawingParams.deviceData.r > drawingParams.rMax) ? drawingParams.deviceData.r : drawingParams.rMax;
  drawingParams.yMax = (drawingParams.deviceData.y > drawingParams.yMax) ? drawingParams.deviceData.y : drawingParams.yMax;
  drawingParams.pMax = (drawingParams.deviceData.p > drawingParams.pMax) ? drawingParams.deviceData.p : drawingParams.pMax;
  let x = map(drawingParams.deviceData.r, 0, 3, 0, width / 2);
  let y = map(drawingParams.deviceData.p, 0, 1.5, 0, height / 2);
  let bg = map(drawingParams.deviceData.y, 0, 1.5, 0, 255);
  background(bg);
  ellipse(x, y, 20);

  // Log globals
  if (loggingParams) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }
}


function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    save(saveParams.sketchName + '.jpg');
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

}

function mousePressed() {
  device.makeVibrate();
}

function mouseReleased() {

}

function mouseDragged() {

}

function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}



/* ###########################################################################
Service Functions
############################################################################ */

function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}

function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}

function windowResized() {
  resizeMyCanvas();
}

function logInfo(content) {
  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }
}

