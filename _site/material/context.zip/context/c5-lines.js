/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

let saveParams = {
  sketchName: "L2"
}

let img;
let lines = {};

// Params for canvas
let canvasParams = {
  holder: document.getElementById("canvas"),
  state: false,
  mouseX: false,
  mouseY: false,
  background: 0
};
getCanvasHolderSize();

// Params for the drawing
let drawingParams = {
  pixelSize: 15,
  pixelSizeMin: 3,
  pixelSizeMax: 20,
  splitPosition: 50,
  rand: 0
};

// Params for logging
let loggingParams = {
  targetDrawingParams: document.getElementById("drawingParams"),
  targetCanvasParams: document.getElementById("canvasParams"),
  state: false
};



/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */





/* ###########################################################################
P5 Functions
############################################################################ */

function preload() {
  loadImage('img/farbig.jpg', setImage);
}

function setImage(loadedImageFile) {
  img = loadedImageFile;
  img.resize(500, 0);
}

function setup() {

  let canvas = createCanvas(canvasParams.w, canvasParams.h);
  canvas.parent("canvas");

  //colorMode(HSB, 360, 100, 100, 100);
  angleMode(DEGREES);
  noStroke();
  smooth();
  //frameRate(0.5);

  let colorGUI = createGui('Params');
  drawingParams.sizeMax = height;
  colorGUI.addObject(drawingParams);

  strokeWeight(1);
  //strokeCap(SQUARE);

  // only call draw when then gui is changed
  noLoop();
}


function draw() {

  lines = {};

  background(0);
  let splitPosition = map(drawingParams.splitPosition, 0, 100, 0, width); 
  let tileCount = floor(width / drawingParams.pixelSize);
  let rectSize = width / tileCount;

  img.loadPixels();
  
  randomSeed(0);
  for (let gridX = 0; gridX < tileCount; gridX++) {
    
    for (let gridY = 0; gridY < tileCount; gridY++) {
      
      let rand = random(- drawingParams.rand, drawingParams.rand);
      let px = int(gridX * rectSize);
      let py = int(gridY * rectSize);
      let i = (py * img.width + px) * 4;
      let c = color(img.pixels[i], img.pixels[i + 1], img.pixels[i + 2], img.pixels[i + 3]);
      fill(c);
      if (px < splitPosition) { 
        noStroke();
        ellipse(gridX * rectSize, gridY * rectSize, drawingParams.pixelSize);
      } else {
        stroke(c);
        strokeWeight(drawingParams.pixelSize -1);
        
        let yPos = gridY * rectSize;
        if (!lines[yPos]) { 
          noFill();
          //line(gridX * rectSize, yPos, width, gridY * rectSize + rand);
          let x1 = gridX * rectSize -1;
          let y1 = yPos;
          let x2 = ((width - x1) / 4) +x1;
          let y2 = y1;
          let x3 = x2;
          let y3 = y1;
          let x4 = width;
          let y4 = gridY * rectSize + rand;
          bezier(x1, y1, x2, y2, x3, y3, x4, y4);
          lines[yPos] = true;
        }

      }
    }
  }
  

  // Log globals
  if (loggingParams) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }
}


function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    save(saveParams.sketchName + '.jpg');
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

}

function mousePressed() {

}

function mouseReleased() {

}

function mouseDragged() {

}





/* ###########################################################################
Service Functions
############################################################################ */

function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}

function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}

function windowResized() {
  resizeMyCanvas();
}

function logInfo(content) {
  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }
}

