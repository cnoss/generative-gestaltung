/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

let buffer = [];
let size = 0;
let pSize = 0;

let saveParams = {
  sketchName: "C1"
}


// Params for canvas
let canvasParams = {
  holder: document.getElementById("canvas"),
  state: false,
  mouseX: false,
  mouseY: false,
  background: 0
};
getCanvasHolderSize();

// Params for the drawing
let drawingParams = {
  maxLineWeight: 50,
  maxLineWeightMax: 50
};

// Params for logging
let loggingParams = {
  targetDrawingParams: document.getElementById("drawingParams"),
  targetCanvasParams: document.getElementById("canvasParams"),
  state: false
};



/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */





/* ###########################################################################
P5 Functions
############################################################################ */


function setup() {

  let canvas = createCanvas(canvasParams.w, canvasParams.h);
  canvas.parent("canvas");

  //colorMode(HSB, 360, 100, 100, 100);
  angleMode(DEGREES);
  //noStroke();
  smooth();

  let sketchGUI = createGui('Params');
  sketchGUI.addObject(drawingParams);

  fill(255, 20);
  noStroke();
  // only call draw when then gui is changed
  // noLoop();
}


function draw() {

  if (mouseIsPressed) {
    let distance = dist(mouseX, mouseY, pmouseX, pmouseY);
    let sizeDiff = (size - pSize) / distance;
    let posX = pmouseX;
    let posY = pmouseY;
    let xMove = (mouseX - pmouseX) / distance;
    let yMove = (mouseY - pmouseY) / distance;
    size = (map(distance, 0, 50, 30, 5));
    let trans = (map(distance, 0, 50, 20, 20));

    fill(255, trans);
    for (let i = 0; i < distance; i++) {
      ellipse(posX, posY, size);
      push();
      translate(width,0);
      scale(-1.0, 1.0);
      ellipse(posX, posY, size);
      pop();

      push();
      translate(0,height);
      scale(1.0, -1.0);
      ellipse(posX, posY, size);
      pop();

      push();
      translate(width,height);
      scale(-1.0, -1.0);
      ellipse(posX, posY, size);
      pop();
      //ellipse((posX * -1) + width, posY, size);
      size += sizeDiff;
      posX += xMove;
      posY += yMove;
    }
    pSize = size;
  
}


  // Log globals
  if (loggingParams) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }
}


function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    save(saveParams.sketchName + '.jpg');
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

}

function mousePressed() {

}

function mouseReleased() {

}

function mouseDragged() {

}

function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}



/* ###########################################################################
Service Functions
############################################################################ */

function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}

function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}

function windowResized() {
  resizeMyCanvas();
}

function logInfo(content) {
  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }
}

