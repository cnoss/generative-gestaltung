/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/


############################################################################ */


let buffer = [];
let size = 0;
let pSize = 0;
let virtualCanvas;
let mic;

let saveParams = {
  sketchName: "C1"
}

let video;

// Params for canvas
let canvasParams = {
  holder: document.getElementById("canvas"),
  state: false,
  mouseX: false,
  mouseY: false,
  background: 0
};
getCanvasHolderSize();

// Params for the drawing
let drawingParams = {
  rotAngle: 0,
  virtualCanvases: 1,
  maxBrightness: 10,
  farbe: 0,
  spread: 10
};

// Params for logging
let loggingParams = {
  targetDrawingParams: document.getElementById("drawingParams"),
  targetCanvasParams: document.getElementById("canvasParams"),
  state: false
};



/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */

function doDraw() { 
  background(0);
  drawingParams.rotAngle = 360 / drawingParams.virtualCanvases;

  translate(width / 2, height / 2);
  
  for (let i = 0; i < drawingParams.virtualCanvases; i++) { 
    push()
    rotate(i * drawingParams.rotAngle);
   
    image(virtualCanvas, (width * -0.5) + drawingParams.spread, (height * -0.5)  + drawingParams.spread);
    pop();

  }
}


/* ###########################################################################
P5 Functions
############################################################################ */


function setup() {

  let canvas = createCanvas(canvasParams.w, canvasParams.h);
  canvas.parent("canvas");

  
  
  //blendMode(SCREEN);
  noStroke();
  angleMode(DEGREES);

  let sketchGUI = createGui('Params');
  sketchGUI.addObject(drawingParams);

  // Video Input
  pixelDensity(1);
  video = createCapture(VIDEO);
  video.size(1,1);
  
  // Audio Input
  mic = new p5.AudioIn();
  mic.start();

  virtualCanvas = createGraphics(width, height);
  virtualCanvas.colorMode(HSB, 360, 100, 100, 100);
  virtualCanvas.fill(255, 2);
  //virtualCanvas.noStroke();
  virtualCanvas.stroke(0, 10);
  virtualCanvas.strokeWeight(1);
  virtualCanvas.smooth();

  // only call draw when then gui is changed
  // noLoop();
}


function draw() {
  
  video.loadPixels();
  drawingParams.maxBrightness = (video.pixels[0] > drawingParams.maxBrightness) ? video.pixels[0] : drawingParams.maxBrightness;
  drawingParams.farbe = map(video.pixels[0], 0, drawingParams.maxBrightness, 0, 360); 
  
  //drawingParams.virtualCanvases = map(mic.getLevel(), 0, 1, 0, 120);
  drawingParams.spread = floor(map(mic.getLevel(), 0, 1, 1, width/ 4));
  
  if (mouseIsPressed) {
    let distance = dist(mouseX, mouseY, pmouseX, pmouseY);
    let sizeDiff = (size - pSize) / distance;
    let posX = pmouseX;
    let posY = pmouseY;
    let xMove = (mouseX - pmouseX) / distance;
    let yMove = (mouseY - pmouseY) / distance;
    size = (map(distance, 0, 50, 2, 20));
    
    let trans = map(dist(pmouseX, pmouseY, width / 2, height / 2), 0, height / 2, 20, 1);
    
    virtualCanvas.fill(drawingParams.farbe, 90, 100, trans);
    for (let i = 0; i < distance; i++) {
      virtualCanvas.ellipse(posX, posY, size);
      size += sizeDiff;
      posX += xMove;
      posY += yMove;
    }
    pSize = size;

    
  }

  doDraw();

  // Log globals
  if (loggingParams) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }
}

function keyPressed() {

  if (keyCode === 81) { // Q-Key
    virtualCanvas.clear();
    doDraw();
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    save(saveParams.sketchName + '.jpg');
  }

  if (keyCode === 49) { // 1-Key
    if (drawingParams.virtualCanvases > 2) { 
      drawingParams.virtualCanvases--;
      doDraw();
    }
  }

  if (keyCode === 50) { // 2-Key
    drawingParams.virtualCanvases++;
    doDraw();
  }

}

function mousePressed() {

}

function mouseReleased() {

}

function mouseDragged() {

}

function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}



/* ###########################################################################
Service Functions
############################################################################ */

function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}

function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}

function windowResized() {
  resizeMyCanvas();
}

function logInfo(content) {
  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }
}

