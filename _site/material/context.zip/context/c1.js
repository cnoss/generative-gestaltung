/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */


let saveParams = {
  sketchName: "C1"
}

let distanceMax = 0;
let sw = 0;

// Params for canvas
let canvasParams = {
  holder: document.getElementById("canvas"),
  state: false,
  mouseX: false,
  mouseY: false,
  background: 0
};
getCanvasHolderSize();

// Params for the drawing
let drawingParams = {
  maxLineWeight: 50,
  maxLineWeightMax: 50
};

// Params for logging
let loggingParams = {
  targetDrawingParams: document.getElementById("drawingParams"),
  targetCanvasParams: document.getElementById("canvasParams"),
  state: false
};



/* ###########################################################################
Classes
############################################################################ */





/* ###########################################################################
Custom Functions
############################################################################ */





/* ###########################################################################
P5 Functions
############################################################################ */


function setup() {

  let canvas = createCanvas(canvasParams.w, canvasParams.h);
  canvas.parent("canvas");

  //colorMode(HSB, 360, 100, 100, 100);
  angleMode(DEGREES);
  //noStroke();
  smooth();

  let sketchGUI = createGui('Params');
  sketchGUI.addObject(drawingParams);

  fill(255, 40);
  stroke(255, 40);
  strokeWeight(10);
  // only call draw when then gui is changed
  // noLoop();
}


function draw() {

  if (mouseIsPressed === true) {
    line(mouseX, mouseY, pmouseX, pmouseY);

    let distance = dist(mouseX, mouseY, pmouseX, pmouseY);
    distanceMax = (distance > distanceMax) ? distance : distanceMax;

    sw = (distance < 5) ? sw + 0.3 : map(distance, 0, distanceMax, 1, drawingParams.maxLineWeight);
    strokeWeight(sw);
    stroke(255, map(distance, 0, distanceMax, 100, 10));
    
  }
  

  // Log globals
  if (loggingParams) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }
}


function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    save(saveParams.sketchName + '.jpg');
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

}

function mousePressed() {

}

function mouseReleased() {

}

function mouseDragged() {

}

function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}



/* ###########################################################################
Service Functions
############################################################################ */

function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}

function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}

function windowResized() {
  resizeMyCanvas();
}

function logInfo(content) {
  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }
}

