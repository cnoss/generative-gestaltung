/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

const saveParams = {
  sketchName: "gg-sketch"
}

// Params for canvas
const canvasParams = {
  holder: document.getElementById('canvas'),
  state: false,
  mouseX: false,
  mouseY: false,
  mouseLock: false,
  background: 0,
  gui: true,
  mode: 'canvas', // canvas or svg … SVG mode is experimental 
};
getCanvasHolderSize();

// Params for the drawing
const drawingParams = {
  elementSize: 30,
  elementeSizeMax: 300,
  elementHeight: 5,
  strokeAlpha: 100,
  fillAlpha: 30,
};

// Params for logging
const loggingParams = {
  targetDrawingParams: document.getElementById('drawingParams'),
  targetCanvasParams: document.getElementById('canvasParams'),
  state: false
};


const elemente = [];
const anzahlDerElemente = 100;


/* ###########################################################################
Classes
############################################################################ */

// Klasse für die Elemente
class Element {

  // Konstruktor: wird aufgerufen, wenn ein neues Objekt der Klasse erstellt wird
  // im Konstruktor können Werte für die Eigenschaften des Objekts festgelegt werden, hier x und y
  // -> https://developer.mozilla.org/de/docs/Web/JavaScript/Reference/Classes/constructor
  constructor(x, y) {
    this.x = x; // Koordinate x- und y des Objekts
    this.y = y; // das this bezieht sich auf die Variable des Objekts, nicht auf die übergebene Variable
  }

  // Methode zum Zeichnen des Elements, diese Methode gehört zur Klasse Element
  zeichnen() {

    const { strokeAlpha } = drawingParams; // das gleiche wie -> const strokeAlpha = drawingParams.strokeAlpha;
    const { fillAlpha } = drawingParams;
    const { elementSize } = drawingParams;
    const { elementHeight } = drawingParams;

    // Berechnung des Winkels zwischen Maus und Element
    // atan2() berechnet den Winkel zwischen zwei Punkten -> https://p5js.org/reference/#/p5/atan2
    const angle = atan2(canvasParams.mouseY - this.y, canvasParams.mouseX - this.x) + 90;

    // Berechnung der Position des Rechtecks
    const x1 = (- elementSize /4);

    // push() und pop() werden verwendet, um den Zeichenkontext zu speichern und wiederherzustellen
    // push() sagt, dass wir ab hier Transformationen vornehmen wollen -> ab hier gelten die Transformationen 
    push();
      translate(this.x, this.y); // verschiebe den Ursprung des Koordinatensystems an die Position des Elements
      rotate(angle);  // rotiere das Koordinatensystem um den Winkel angle

      strokeWeight(1);
      stroke(0, 0, 100, strokeAlpha);
      fill(0, 0, 100, fillAlpha);
    
      rect(x1, 0, elementSize / 2, elementHeight); // zeichne ein Rechteck
    pop(); // ab hier gelten die Transformationen nicht mehr, translate und rotate werden zurückgesetzt
  }
}




/* ###########################################################################
Custom Functions
############################################################################ */

function erzeugeElemente() { 

  const { elementSize } = drawingParams; // das gleiche wie -> const elementSize = drawingParams.elementSize;

  // Berechnung der Dimension der Formation
  let dimFormation = anzahlDerElemente * elementSize;

  // Berechnung der Verschiebung der Formation
  let shiftX = width/2 - dimFormation /2;
  let shiftY = height/2 - dimFormation /2;

  // wir bauen ein imaginäres Koordinatensystem auf um die Elemente in ein Raster zu platzieren
  // dafür brauchen wir zwei Schleifen, die die Elemente zeilen- und spaltenweise in einem Raster anordnen
  // bevor sie jedoch in das Raster gezeichnet werden, werden sie in einem Array gespeichert
  for (let cols = 0; cols < anzahlDerElemente; cols++) {
    for (let rows = 0; rows < anzahlDerElemente; rows++) {
      let x = shiftX + cols * elementSize;
      let y = shiftY + rows * elementSize;
      elemente.push(new Element(x, y));
    }
  }
}




/* ###########################################################################
P5 Functions
############################################################################ */

function setup() {

  let canvas;
  if (canvasParams.mode === 'SVG') {
    canvas = createCanvas(canvasParams.w, canvasParams.h, SVG);
  } else { 
    canvas = createCanvas(canvasParams.w, canvasParams.h);
    canvas.parent("canvas");
  }

  // Display & Render Options
  frameRate(25);
  angleMode(DEGREES);
  smooth();

  // GUI Management
  if (canvasParams.gui) { 
    const sketchGUI = createGui('Params');
    sketchGUI.addObject(drawingParams);
    //noLoop();
  }

  // Anything else
  fill(200);
  stroke(0);
  colorMode(HSB, 360, 100, 100, 100);

  stroke(0,0,100,20);
  strokeWeight(2);
  erzeugeElemente(); // erzeuge die Elemente, die in einem Array gespeichert werden
}



function draw() {

  /* ----------------------------------------------------------------------- */
  // Log globals
  if (!canvasParams.mouseLock) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }

  /* ----------------------------------------------------------------------- */
  // Provide your Code below
  background(0,0,0,100);

  // wir gehen durch das Array und rufen für jedes Element die Methode zeichnen() auf
  // erst dadurch werden die Elemente gezeichnet
  // forEach() ist eine Alternative zur For-Schleife 
  // -> https://developer.mozilla.org/de/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
  elemente.forEach(
    (element) => { 
      element.zeichnen();
    }
  );
}



function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    const suffix = (canvasParams.mode === "canvas") ? '.jpg' : '.svg';
    const fragments = location.href.split(/\//).reverse();
    const suggestion = fragments[1] ? fragments[1] : 'gg-sketch';
    const fn = prompt(`Filename for ${suffix}`, suggestion);
    if (fn !== null) save(fn + suffix);
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

  if (keyCode === 76) { // L-Key
    if (!canvasParams.mouseLock) {
      canvasParams.mouseLock = true;
    } else { 
      canvasParams.mouseLock = false;
    }
    document.getElementById("canvas").classList.toggle("mouseLockActive");
  }


}



function mousePressed() {}



function mouseReleased() {}



function mouseDragged() {}



function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}





/* ###########################################################################
Service Functions
############################################################################ */



function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}



function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}



function windowResized() {
  resizeMyCanvas();
}



function logInfo(content) {

  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }

}

