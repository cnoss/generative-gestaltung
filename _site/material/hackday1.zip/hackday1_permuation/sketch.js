/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

const saveParams = {
  sketchName: "gg-sketch"
}

// Params for canvas
const canvasParams = {
  holder: document.getElementById('canvas'),
  state: false,
  mouseX: false,
  mouseY: false,
  mouseLock: false,
  background: 0,
  gui: true,
  mode: 'canvas', // canvas or svg … SVG mode is experimental 
};
getCanvasHolderSize();

// Params for the drawing
const drawingParams = {
  anzahl: 10,
  anzahlMax: 40,
};

// Params for logging
const loggingParams = {
  targetDrawingParams: document.getElementById('drawingParams'),
  targetCanvasParams: document.getElementById('canvasParams'),
  state: false
};


/* ###########################################################################
Classes
############################################################################ */



/* ###########################################################################
Custom Functions
############################################################################ */

function zeichneElemente() { 

  const { anzahl } = drawingParams; // das gleiche wie -> const anzahl = drawingParams.anzahl;
  const groesse = width / anzahl;   // groesse des Elements = Breite des Canvas / Anzahl der Elemente
  
  // wir teilen das Canvas in ein Raster auf und zeichnen in jedes Rasterfeld ein Element
  for (let cols = 0; cols < anzahl; cols++) {     // Schleife für die Spalten, so viele Spalten wie Elemente
    for (let rows = 0; rows < anzahl; rows++) {   // Schleife für die Zeilen, so viele Zeilen wie Elemente
      
      // x- und y-Position des Elements -> Spaltennummer * groesse des Elements
      // Beispiel: 3. Spalte * 100px = 300px 
      //          -> 300px ist dann Startpunkt der 3. Spalte
      const x = cols * groesse;   
      const y = rows * groesse;

      // wir berechnen für die Rotation eine Zufallszahl zwischen 0 und 3
      // mit round() runden wir die Zufallszahl auf die nächste ganze Zahl
      // mit * 90 multiplizieren wir die Zufallszahl mit 90 (um 90°, 180° oder 270° zu erhalten)
      const rotation = round(random(0, 3)) * 90;

      // um die Elemente so zu zeichnen, dass sie innerhalb des Quadrantes sichtbar sind, 
      // müssen wir das Koordinatensystem verschieben und drehen
      // für jedes Element müssen wir das Koordinatensystem wieder zurücksetzen
      // das machen wir mit push() und pop()
      push(); // push() sagt, dass wir ab hier Transformationen vornehmen wollen -> ab hier gelten die Transformationen 
        
        /* Achtung, ab hier wird es komplexer - ihr muesst die folgenden translates nicht unbedingt verstehen ;) */
        
        // mit diesem ersten translate gehen wir zum Anfang des jeweiligen Quadrats bzw. Rasterfelds
        // wir verschieben das Koordinatensystem an den Anfang des Rasterfelds, in dem das Element gezeichnet werden soll
        // der Nullpunkt liegt jetzt also links oben im Rasterfeld
        translate(x, y);
        
        // mit diesem zweiten translate gehen wir in die Mitte des Rasterfelds
        // der Nullpunkt liegt jetzt also in der Mitte des Rasterfelds
        translate(groesse/2, groesse/2);

        // mit diesem rotate drehen wir das Koordinatensystem um die Zufallszahl (90°, 180° oder 270°)
        rotate(rotation);

        // wir verschieben den Nullpunkt jetzt wieder an den Rand zuruck, 
        // das ist dann entweder links oben, rechts oben, rechts unten oder links unten  
        translate(-groesse/2, -groesse/2); 
        
        const posX = 0;
        const posY = 0;
        const breite = groesse * 2;
        const hoehe = groesse * 2;
        
        fill(360,0,0,100);

        // arc() zeichnet einen Kreisbogen, also nur einen Teil des Kreises -> https://p5js.org/reference/#/p5/arc
        arc(posX, posY, breite, hoehe, 0, 90); // 

      pop(); // ab hier gelten die Transformationen nicht mehr, translate und rotate werden zurückgesetzt

    }
  }
}



/* ###########################################################################
P5 Functions
############################################################################ */

function setup() {

  let canvas;
  if (canvasParams.mode === 'SVG') {
    canvas = createCanvas(canvasParams.w, canvasParams.h, SVG);
  } else { 
    canvas = createCanvas(canvasParams.w, canvasParams.h);
    canvas.parent("canvas");
  }

  // Display & Render Options
  frameRate(25);
  angleMode(DEGREES);
  smooth();

  // GUI Management
  if (canvasParams.gui) { 
    const sketchGUI = createGui('Params');
    sketchGUI.addObject(drawingParams);
    //noLoop();
  }

  // Anything else
  fill(200);
  noStroke();
  colorMode(HSB, 360, 100, 100, 100);
  
}



function draw() {

  /* ----------------------------------------------------------------------- */
  // Log globals
  if (!canvasParams.mouseLock) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }

  /* ----------------------------------------------------------------------- */
  // Provide your Code below
  
  background(360,0,100,10);
  fill(360,0,0,50);

  randomSeed(0); // damit die Zufallszahlen, die im Sketch erzeugt werden, immer gleich sind
  zeichneElemente(); // hier wird die Funktion zum Zeichnen der Elemente aufgerufen

}



function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    const suffix = (canvasParams.mode === "canvas") ? '.jpg' : '.svg';
    const fragments = location.href.split(/\//).reverse();
    const suggestion = fragments[1] ? fragments[1] : 'gg-sketch';
    const fn = prompt(`Filename for ${suffix}`, suggestion);
    if (fn !== null) save(fn + suffix);
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

  if (keyCode === 76) { // L-Key
    if (!canvasParams.mouseLock) {
      canvasParams.mouseLock = true;
    } else { 
      canvasParams.mouseLock = false;
    }
    document.getElementById("canvas").classList.toggle("mouseLockActive");
  }


}



function mousePressed() {}



function mouseReleased() {}



function mouseDragged() {}



function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}





/* ###########################################################################
Service Functions
############################################################################ */



function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}



function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}



function windowResized() {
  resizeMyCanvas();
}



function logInfo(content) {

  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }

}

