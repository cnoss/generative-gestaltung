/*jshint esversion: 6 */

/* ############################################################################ 

Kurs «Generative Gestaltung» an der TH Köln
Christian Noss
christian.noss@th-koeln.de
https://twitter.com/cnoss
https://cnoss.github.io/generative-gestaltung/

############################################################################ */

const saveParams = {
  sketchName: "gg-sketch"
}

// Params for canvas
const canvasParams = {
  holder: document.getElementById('canvas'),
  state: false,
  mouseX: false,
  mouseY: false,
  mouseLock: false,
  background: 0,
  gui: true,
  mode: 'canvas', // canvas or svg … SVG mode is experimental 
};
getCanvasHolderSize();

// Params for the drawing
const drawingParams = {
  bgAlpha: 10,
  amplifer: 1,
  ampliferMin: 0.1,
  ampliferMax: 5,
  ampliferStep: 0.1,
  zeigeAgent: [false, true],
};

// Params for logging
const loggingParams = {
  targetDrawingParams: document.getElementById('drawingParams'),
  targetCanvasParams: document.getElementById('canvasParams'),
  state: false
};

const tolleElemente = [];
const size = 50;
const padding = 10;
const anzahl = 7;

let agentX = 50;
let agentY = 50;

let agentXDirection = 1;
let agentYDirection = 1;

const agentXSpeed = 10;
const agentYSpeed = 11;


/* ###########################################################################
Classes
############################################################################ */

class krassesElement {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.bri = 100;
    this.alpha = 100;
  }


  show() {
    
    // const distance = dist(agentX, agentY, this.x, this.y);
    // const hypothenuse = dist(0, 0, width/drawingParams.amplifer, height/drawingParams.amplifer);
    // this.size = map(distance, 0, hypothenuse, 10, 100);
    // 
    // this.winkel = map(distance, 0, hypothenuse, 0, 360);
    // this.alpha = map(distance, 0, hypothenuse, 10, 100);
    // this.bri = map(distance, 0, hypothenuse, 50, 100);
    
  
    noFill();
    stroke(0, 0, this.bri,this.alpha);
    fill(0, 0, this.bri,this.alpha * 0.2);
    
    push();
    translate(this.x, this.y);
    ellipse(0, 0, this.size, this.size);
    pop();
  }
}



/* ###########################################################################
Custom Functions
############################################################################ */

function showCross() {
  stroke(0);
  line(width/2, 0, width/2, height);
  line(0, height/2, width, height/2);
}

function erzeugeRasterMitElementen() {
  const totalSize = (anzahl * size + (anzahl - 1) * padding) - size;

  for(let col = 0; col < anzahl; col++) {
    for(let row = 0; row < anzahl; row++) {
      const x = - totalSize / 2 + col * (padding + size);
      const y = - totalSize / 2 + row * (padding + size);
      tolleElemente.push(new krassesElement(x, y, size));
    }
  }
}


/* ###########################################################################
P5 Functions
############################################################################ */

function setup() {

  let canvas;
  if (canvasParams.mode === 'SVG') {
    canvas = createCanvas(canvasParams.w, canvasParams.h, SVG);
  } else { 
    canvas = createCanvas(canvasParams.w, canvasParams.h);
    canvas.parent("canvas");
  }

  // Display & Render Options
  frameRate(25);
  angleMode(DEGREES);
  smooth();

  // GUI Management
  if (canvasParams.gui) { 
    const sketchGUI = createGui('Params');
    sketchGUI.addObject(drawingParams);
    //noLoop();
  }

  // Anything else
  fill(200);
  stroke(0);
  colorMode(HSB, 360, 100, 100, 100);

  erzeugeRasterMitElementen();
}



function draw() {

  /* ----------------------------------------------------------------------- */
  // Log globals
  if (!canvasParams.mouseLock) {
    canvasParams.mouseX = mouseX;
    canvasParams.mouseY = mouseY;
    logInfo();
  }

  /* ----------------------------------------------------------------------- */
  // Provide your Code below
  
  background(0,0,0,drawingParams.bgAlpha);
  fill(0,0,100,100);

  /* Agent */
  if(drawingParams.zeigeAgent===true) {
    push();
    translate(agentX, agentY);
    fill(0,0,100,100);
    noStroke();
    ellipse(0, 0, 5, 5);
    pop();
  }

  agentX += agentXDirection * agentXSpeed;
  agentY += agentYDirection * agentYSpeed;

  if (agentX > width || agentX < 0) agentXDirection *= -1;
  if (agentY > height || agentY < 0) agentYDirection *= -1;


  translate(width/2, height/2);

  tolleElemente.forEach(element => {
    element.show();
  });


  
}



function keyPressed() {

  if (keyCode === 81) { // Q-Key
  }

  if (keyCode === 87) { // W-Key
  }

  if (keyCode === 89) { // Y-Key
  }

  if (keyCode === 88) { // X-Key
  }

  if (keyCode === 83) { // S-Key
    const suffix = (canvasParams.mode === "canvas") ? '.jpg' : '.svg';
    const fragments = location.href.split(/\//).reverse();
    const suggestion = fragments[1] ? fragments[1] : 'gg-sketch';
    const fn = prompt(`Filename for ${suffix}`, suggestion);
    save(fn + suffix);
  }

  if (keyCode === 49) { // 1-Key
  }

  if (keyCode === 50) { // 2-Key
  }

  if (keyCode === 76) { // L-Key
    if (!canvasParams.mouseLock) {
      canvasParams.mouseLock = true;
    } else { 
      canvasParams.mouseLock = false;
    }
    document.getElementById("canvas").classList.toggle("mouseLockActive");
  }


}



function mousePressed() {}



function mouseReleased() {}



function mouseDragged() {}



function keyReleased() {
  if (keyCode == DELETE || keyCode == BACKSPACE) clear();
}





/* ###########################################################################
Service Functions
############################################################################ */



function getCanvasHolderSize() {
  canvasParams.w = canvasParams.holder.clientWidth;
  canvasParams.h = canvasParams.holder.clientHeight;
}



function resizeMyCanvas() {
  getCanvasHolderSize();
  resizeCanvas(canvasParams.w, canvasParams.h);
}



function windowResized() {
  resizeMyCanvas();
}



function logInfo(content) {

  if (loggingParams.targetDrawingParams) {
    loggingParams.targetDrawingParams.innerHTML = helperPrettifyLogs(drawingParams);
  }

  if (loggingParams.targetCanvasParams) {
    loggingParams.targetCanvasParams.innerHTML = helperPrettifyLogs(canvasParams);
  }

}

